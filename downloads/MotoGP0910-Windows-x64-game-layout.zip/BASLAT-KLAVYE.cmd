@echo off
"%~dp0motogp0910.exe" --mnk_mode=true
