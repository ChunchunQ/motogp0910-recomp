MotoGP 09/10 - Windows x64 Experimental LAN multiplayer - ReXGlue 0.10.0.24-dev.gbd833a2

EXPERIMENTAL LAN: Guest XNet/session and UDP/VDP socket integration is included.
General > Enable LAN (Experimental); automatic rooms, optional host IPv4 fallback.
Use the same package on both PCs and unranked Player Match on LAN / Radmin.
No Xbox Live login or dedicated server. Offline remains the default.
LAN startup fix: 17 targeted actual-SDK Windows/Wine checks passed.
Empty Auto-IP command-line values no longer swallow the next option.
The user reported successful two-PC Radmin racing with the previous executable.
LOBBY FIX: Retain selected search results; accept null join-only slots on leave.
Targeted Windows regressions passed; revised Radmin gameplay needs user testing.
Read lan-readme.txt for the exact two-PC steps and unsupported features.

ICONS: Game EXE uses the supplied MotoGP 09/10 cover. Launcher EXE uses
the supplied MotoGP logo. Both embed seven Windows icon sizes (16-256 px).

ACHIEVEMENTS: F7 opens the dark MotoGP list with search, unlocked/locked filters,
progress and original achievement icons. Esc or Close returns to the game.
Unlock notifications fade in at the bottom right with a soft 450 ms cue.
F7 > Unlock sound / volume can disable or adjust it; game master/mute applies.
English/Turkish follows Launcher language at game startup.
Keep resources/ui with the complete build. See achievements-readme.txt.

CRASH REPORTS: General > Extended crash diagnostics (default ON).
The separate monitor captures fatal errors including fast-fail 0xC0000409.
Reports: logs/crash-*/report.txt and crash.dmp, with latest log and settings.
Error report also copies the latest native crash folder.
Keep motogp0910-crash-monitor.exe and motogp0910.map with the other files.
A minidump can contain memory fragments and local paths.
Read crash-readme.txt for coverage, fallback location and sharing steps.

STABILITY: Reject out-of-range/overflowing TLS slots, preserve owned launch paths,
use unique atomic thread IDs and a thread-safe host processor count cache.
FILETIME calendar conversions preserve the 1601 epoch and 100 ns precision.
Unpinned CPU updates avoid host topology queries and repeated warnings.
FPS pacing and ultrawide HUD diagnostics avoid redundant hot-path work.
Earlier Windows CPU/UI regressions passed under Wine; revised LAN fix needs native testing.

ADVANCED: Motion blur (speed), depth of field, dynamic shadows, shadow render distance.
Game default keeps the original behavior; Off disables the selected effect.
Shadow distance offers game default / 45 / 90 / 180.
The shadow override is scoped and preserves the original track tweak on return.
FSR 2/3: Experimental Windows D3D12 providers; no frame generation.
Synthesized far-depth/zero-motion inputs, history reset each frame.
This does not provide proper temporal reconstruction or lower scene render cost.
Quality modes resample the resolved scene; FSR 1 remains the safe default.
ULTRAWIDE: Auto / 16:9 / 21:9 / 32:9, horizontal-plus camera and central HUD.
Wide modes are experimental; broad gameplay and Windows GPU testing is pending.

GENERAL: Opens on General every launch. Game folder, language and Button prompts.
The folder and launcher-language controls appear only on General.
Game languages: English, French, German, Spanish and Italian.
Prompt styles: Automatic, PlayStation 3, Xbox 360 and Keyboard.
OUTPUT: Window sizes are capped at the physical monitor's native resolution.
An oversized previous window setting falls back to Automatic / desktop in the UI.
Internal resolution labels now use 1x / 2x / 3x.

CAREER TEXTURES: Synchronous GPU resolve readback is enabled only during
custom rider/bike livery generation. BOTH matching runtime DLLs are required.
13 scope/ABI checks (16 guest calls) passed on Linux and Windows/Wine.
The first career race needs local Windows visual verification.
LAUNCHER: Removed the lower-left SDK/platform label and its covering box.
The decorative stripes remain visible to the bottom of the sidebar.

PHYSICS DATA: Preserves serialized collision coordinates during endian conversion.
192 Linux and Windows/Wine field/record/ABI checks passed.
The user verified 4-5 Qatar Time Trial laps without falling through the track.
Repair messages in logs contain PHYSICS_ASSET_FIX.

UPGRADE: Extract the complete ZIP, including resources/controller.
Replace the EXEs AND both rexruntime.dll / rexgpu-xenos.dll.
Keep your existing game folder, configuration and saves.

1. ZIP'i program klasorune cikart; motogp0910.exe ve DLL'ler burada kalsin.
2. Tum orijinal oyun dosyalarini game altklasorune koy:
   game/default.xex, game/xenondata/, game/nxeart/ ve diger disk dosyalari.
3. default.xexp patch'ini ve kendi title update dosyan
   TU_11K61VG_0000004000000.0000000000081 dosyasini da game icine koy.
4. motogp0910-launcher.exe dosyasini ac, ayarlarini sec ve PLAY'e bas.
   Arayuz varsayilan olarak Ingilizcedir; General > Launcher language menusunden Turkce secilebilir.
   Dil secimi sonraki acilislarda korunur. Derleme gerekmez.

GRAPHICS: GPU, output size, 720p / 1440p (2K) / 4K internal resolution, native 2x MSAA,
FSR 1.0 / CAS sharpness, anisotropic filtering, FXAA and shader cache.
FSR is spatial: choose 720p internal resolution for 720p to 1080p upscaling.
DISPLAY: Fullscreen, borderless or windowed. Fullscreen can switch monitor Hz.
Borderless uses the desktop resolution/Hz; windowed keeps desktop Hz.
FPS limit is independent, off by default, and does not unlock the game cap.
Selected Hz must be supported at the selected output resolution.
AUDIO: Real master volume 0-100% and mute.
CONTROLS: Edit any binding directly, or use its ... button to capture a key.
Right-click a binding to unbind it or restore its action default.
Examples: Space, Return, Ctrl+K, Shift+Up, Q,I. Esc cancels capture.
Saved settings apply on next launch, including direct motogp0910.exe launch.
Keep both matching runtime DLLs for this nightly stability build.

REPLAY REPAIR: Replace the upper controller row, preserving the lower media row.
All eight full-replay controller sprites now switch Xbox/PS/keyboard styles.
The v2 build incorrectly replaced rewind/camera icons instead of the button row.

PS3 ARTWORK REPAIR: Match the GPU loader's 512-byte BC3 row alignment.
The previous PS3 button build uploaded tightly packed 256-byte rows.
This build pads rows without changing any visible compressed pixel block.

IN-GAME PROMPTS: Automatically switch Xbox / PlayStation / keyboard
symbols after meaningful input. Keyboard caps show your actual saved bindings.
KEYBOARD UPDATE: Rounded dark keycaps, orange MotoGP accents and Open Sans Semibold.
The font is embedded; no font installation or additional texture pack is needed.
Native Windows/Wine drawing, fade, replay and input checks passed; local visuals need testing.
PlayStation: A=cross, B=circle, X=square, Y=triangle; L1/R1 and L2/R2.
Original PS3 stick, stick direction, D-pad and SELECT artwork is included.
The Second Chance/replay LT/RT/LB/RB/B row also switches styles.
Keep resources/controller/ps3-prompts.bin beside the EXE in that subfolder.
All 42 controller textures found in the supplied sharedfrontend bank are included.
There is no separate START or PS/Guide bitmap in that set; literal START text stays.
Native sticks use the original stick pictures; separate L3/R3 labels were not found.
To test PS graphics with an XInput pad, open PowerShell here and run:
.\motogp0910.exe --input_backend=xinput --button_prompt_style=playstation
Fixed styles: --button_prompt_style=xbox / playstation / keyboard
Automatic mode: --button_prompt_style=auto (default).
Use the SDL backend for automatic Sony controller recognition; XInput
wrappers expose an Xbox controller, so use the manual PlayStation style.
Native glyph rendering and virtual Sony/Xbox input checks passed;
physical DualSense detection and Windows gameplay visuals need local testing.

Klavye ve gamepad icin dogrudan motogp0910.exe dosyasini ac; CMD gerekmez.
Enter=Start, Space=A, Backspace=B, W/S/A/D=sol stick, Shift+oklar=D-pad.
Klavye varsayilan olarak aciktir. Ozel mnk_mode=false ayarin varsa korunur.

gamecontrollerdb.txt EXE ile ayni klasorde kalmali; game icine koyma.
Bu dosya SDL gamepad eslemelerini ekler; input_backend=xinput seciminde kullanilmaz.
Kaynak: https://github.com/mdqinc/SDL_GameControllerDB

Ilk acilista uygulama title update icinden default.xexp dosyasini olusturur;
orijinal default.xex degismez. Mevcut default.xexp dosyasi yeniden yazilmaz.
game/default.xex varsa game klasoru onceliklidir. Eski duz yerlesim de desteklenir.
Kayit/cache konumu onceki EXE ile aynidir; kayit dosyalarini tasimak gerekmez.
Bu build 0.0.1.1 oyun surumunu bekler. Windows 10/11 x64 ve uygun Direct3D 12 GPU gerekir.

This package includes only the requested controller artwork, not full game data or TU.
SDK kaynaklari: https://github.com/rexglue/rexglue-sdk/tree/v0.10.0
