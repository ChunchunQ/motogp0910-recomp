Kendi diskinden cikardigin tum oyun dosyalarini bu klasore koy.
default.xex, default.xexp veya TU paketi, xenondata/ ve nxeart/
ayni game klasorunde olmali. EXE ve DLL dosyalari ust klasorde kalir.
Bu paket oyun dosyalarini icermiyor.
