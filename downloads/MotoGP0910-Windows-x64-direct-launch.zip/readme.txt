MotoGP 09/10 - Windows x64 direct EXE launch - ReXGlue v0.10.0

1. ZIP'i program klasorune cikart; motogp0910.exe ve DLL'ler burada kalsin.
2. Tum orijinal oyun dosyalarini game altklasorune koy:
   game/default.xex, game/xenondata/, game/nxeart/ ve diger disk dosyalari.
3. default.xexp patch'ini ve kendi title update dosyan
   TU_11K61VG_0000004000000.0000000000081 dosyasini da game icine koy.
4. Ust klasordeki motogp0910.exe dosyasini ac. Derleme gerekmez.

Klavye ve gamepad icin dogrudan motogp0910.exe dosyasini ac; CMD gerekmez.
Enter=Start, Space=A, Backspace=B, W/S/A/D=sol stick, Shift+oklar=D-pad.
Klavye varsayilan olarak aciktir. Ozel mnk_mode=false ayarin varsa korunur.

Ilk acilista uygulama title update icinden default.xexp dosyasini olusturur;
orijinal default.xex degismez. Mevcut default.xexp dosyasi yeniden yazilmaz.
game/default.xex varsa game klasoru onceliklidir. Eski duz yerlesim de desteklenir.
Kayit/cache konumu onceki EXE ile aynidir; kayit dosyalarini tasimak gerekmez.
Bu build 0.0.1.1 oyun surumunu bekler. Windows 10/11 x64 ve uygun Direct3D 12 GPU gerekir.

Bu paket orijinal oyun dosyalarini veya title update'i icermiyor.
SDK kaynaklari: https://github.com/rexglue/rexglue-sdk/tree/v0.10.0
