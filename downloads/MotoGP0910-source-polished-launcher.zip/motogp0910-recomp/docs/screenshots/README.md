# Gerçek Linux açılış görüntüleri

Bu PNG'ler Xvfb ekranından doğrudan yakalanmıştır; temsili veya üretilmiş görsel değildir.
ReXGlue v0.10.0, tam MotoGP 09/10 disk verileri ve 0.0.1.1 title update kullanılmıştır.

- [Açılış videosundan kare](linux-intro.png)
- [MotoGP 09/10 başlık görüntüsü](linux-title.png)
- [Ana menü, ilk açılış ayarlarından sonra](linux-main-menu.png)

Ana menü görüntüsü tam disk verileriyle gerçek oyun penceresinden alınmıştır.
Bu, yarış veya gerçek Windows GPU doğrulaması değildir; test kapsamı için proje
README'sine bak.

## Windows launcher

- [Graphics / English](launcher-graphics-english.png)
- [Grafik / Türkçe](launcher-graphics-turkish.png)
- [Controls / English](launcher-controls-english.png)
- [Kontroller / Türkçe](launcher-controls-turkish.png)
- [Kompakt kontrol yerleşimi, %75](launcher-controls-turkish-compact.png)

Windows PE launcher Wine/Xvfb altında gerçek arayüzden yakalandı; Windows oyun
grafik/yarış testi değildir. [Launcher test kapsamı](../launcher.md).
