MotoGP 09/10 - Windows x64 polished launcher - ReXGlue v0.10.0

UPGRADE: Replace the EXEs AND both rexruntime.dll / rexgpu-xenos.dll.
Keep your existing game folder, configuration and saves.

1. ZIP'i program klasorune cikart; motogp0910.exe ve DLL'ler burada kalsin.
2. Tum orijinal oyun dosyalarini game altklasorune koy:
   game/default.xex, game/xenondata/, game/nxeart/ ve diger disk dosyalari.
3. default.xexp patch'ini ve kendi title update dosyan
   TU_11K61VG_0000004000000.0000000000081 dosyasini da game icine koy.
4. motogp0910-launcher.exe dosyasini ac, ayarlarini sec ve PLAY'e bas.
   Arayuz varsayilan olarak Ingilizcedir; Language / Dil menusunden Turkce secilebilir.
   Dil secimi sonraki acilislarda korunur. Derleme gerekmez.

GRAPHICS: GPU, output size, 720p / 1440p (2K) / 4K internal resolution, native 2x MSAA,
FSR 1.0 / CAS sharpness, anisotropic filtering, FXAA and shader cache.
FSR is spatial: choose 720p internal resolution for 720p to 1080p upscaling.
Fullscreen uses the desktop size; output window size is for windowed mode.
AUDIO: Real master volume 0-100% and mute.
CONTROLS: Edit any binding directly, or use its ... button to capture a key.
Right-click a binding to unbind it or restore its action default.
Examples: Space, Return, Ctrl+K, Shift+Up, Q,I. Esc cancels capture.
Saved settings apply on next launch, including direct motogp0910.exe launch.
Keep both runtime DLLs: this v0.10.0 pair enables spatial FSR and shared SDL input.

IN-GAME PROMPTS: Automatically switch Xbox / PlayStation / keyboard
symbols after meaningful input. Keyboard caps show your actual saved bindings.
PlayStation: A=cross, B=circle, X=square, Y=triangle; L1/R1 and L2/R2.
Shared stick/directional artwork stays unchanged for PlayStation.
No additional icon images or modified game assets are needed.
To test PS graphics with an XInput pad, open PowerShell here and run:
.\motogp0910.exe --input_backend=xinput --button_prompt_style=playstation
Fixed styles: --button_prompt_style=xbox / playstation / keyboard
Automatic mode: --button_prompt_style=auto (default).
Use the SDL backend for automatic Sony controller recognition; XInput
wrappers expose an Xbox controller, so use the manual PlayStation style.
Native glyph rendering and virtual Sony/Xbox input checks passed;
physical DualSense detection and Windows gameplay visuals need local testing.

Klavye ve gamepad icin dogrudan motogp0910.exe dosyasini ac; CMD gerekmez.
Enter=Start, Space=A, Backspace=B, W/S/A/D=sol stick, Shift+oklar=D-pad.
Klavye varsayilan olarak aciktir. Ozel mnk_mode=false ayarin varsa korunur.

gamecontrollerdb.txt EXE ile ayni klasorde kalmali; game icine koyma.
Bu dosya SDL gamepad eslemelerini ekler; input_backend=xinput seciminde kullanilmaz.
Kaynak: https://github.com/mdqinc/SDL_GameControllerDB

Ilk acilista uygulama title update icinden default.xexp dosyasini olusturur;
orijinal default.xex degismez. Mevcut default.xexp dosyasi yeniden yazilmaz.
game/default.xex varsa game klasoru onceliklidir. Eski duz yerlesim de desteklenir.
Kayit/cache konumu onceki EXE ile aynidir; kayit dosyalarini tasimak gerekmez.
Bu build 0.0.1.1 oyun surumunu bekler. Windows 10/11 x64 ve uygun Direct3D 12 GPU gerekir.

Bu paket orijinal oyun dosyalarini veya title update'i icermiyor.
SDK kaynaklari: https://github.com/rexglue/rexglue-sdk/tree/v0.10.0
